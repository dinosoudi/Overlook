package practica_1;

public class Cabecera {
	
	String Titulo;

	public Cabecera(String titulo) {
		super();
		Titulo = titulo;
	}

	public String getTitulo() {
		return Titulo;
	}

	public void setTitulo(String titulo) {
		Titulo = titulo;
	}
	
}
