package practica_1;

public class Cuerpo {
	
	String mensaje;

	public Cuerpo(String mensaje) {
		super();
		this.mensaje = mensaje;
	}
	
}
