package practica_1;

import java.util.Arrays;

public class MensajeCorreo {
	
	private Cabecera cabecera;
	private ArchAdjunto[] archivosAdjuntos;
	private Cuerpo cuerpo;
	
	MensajeCorreo (Cabecera aux1,Cuerpo msg, ArchAdjunto[] aux2){
		this.cabecera = aux1;
		this.archivosAdjuntos = aux2;
		this.cuerpo = msg;
	}
	
	MensajeCorreo (Cabecera aux1,Cuerpo msg){
		this.cabecera = aux1;
		this.cuerpo = msg;
	}
	
	MensajeCorreo (Cabecera aux1,ArchAdjunto[] aux2){
		this.cabecera = aux1;
		this.archivosAdjuntos = aux2;
	}
	
	MensajeCorreo (Cabecera aux1){
		this.cabecera = aux1;
	}

	@Override
	public String toString() {
		return "MensajeCorreo [cabecera=" + cabecera.getTitulo() + ", archivosAdjuntos=" + Arrays.toString(archivosAdjuntos)
				+ ", cuerpo=" + cuerpo + "]";
	}
	
}
