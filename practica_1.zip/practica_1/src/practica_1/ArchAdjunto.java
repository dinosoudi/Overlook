package practica_1;

public class ArchAdjunto {
	
	String nombreArchivo;

	public ArchAdjunto(String nombreArchivo) {
		super();
		this.nombreArchivo = nombreArchivo;
	}

	public String getNombreArchivo() {
		return nombreArchivo;
	}

	public void setNombreArchivo(String nombreArchivo) {
		this.nombreArchivo = nombreArchivo;
	}

}
