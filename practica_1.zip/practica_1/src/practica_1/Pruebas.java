package practica_1;

public class Pruebas {
	
	public static void main(String[] args) {
		
		
		
		MensajeCorreo prueba1 = new MensajeCorreo(new Cabecera("Wenas"));
		
		
		System.out.println(prueba1.toString());
		
	}
	
}
